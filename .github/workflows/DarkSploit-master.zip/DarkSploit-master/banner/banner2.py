N = '\033[1;37m' # White
G = '\033[32m' # Green
print ""+N+""
print
print " _______"
print "<"+G+" uh oh"+N+" >"
print " -------"
print "  \ "
print "   \                 __"
print "    \               (OO)"
print "     \              (  )"
print "                    /--\ "
print "       __          / \  \ "
print "      UooU\.'@@@@@@'  \  )"
print "      \__/(@@@@@@@@@@@) /"
print "           (@@@@@@@@@)(("
print "           'YY----YY'  \\"
print "            ||    ||    >>"

