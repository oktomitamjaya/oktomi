N = '\033[1;37m' # White
print
print 
print ""+N+""
print "                                          /~\ "
print "                                         ( oo|     they've shutdown"
print "                                         _\=/_     the main reactor."
print "                     _____           #  /  _  \ "
print "                    / (^) \          \\\//|/ \|\\\ "
print "                   _|-----|_          \/  \_/  ||"
print "                  | |=====| |            |\ /| ||"
print "                  |_|  O  |_|            \_ _/ ##"
print "                   ||  O  ||             | | |"
print "                   ||__*__||             | | |"
print "                  |- \___/ -|            []|[]"
print "                  /=\ /=\ /=\            | | |        DARKSPLOIT V.2"
print "[]----------------[-]-[-]-[-]-----------/-]-[-\------------------------[]"
