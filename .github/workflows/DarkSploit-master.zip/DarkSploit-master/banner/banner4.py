# Set Color
L = '\033[1;36m' #L
print ""+L+""
print " ____________"
print "< darksploit >"
print " ------------"
print "       \   ,__,"
print "        \  (oo)____"
print "           (__)    )\ "
print "              ||--|| *"
