# DarkSploit
<br>
DarkSploit Framework hanyalah sebuah tools yang mengandung banyak exploit dan scanner web aplication
<br>
cocok sekali buat para defacer xd
<br>
selain itu tools ini juga bisa dijalankan diandroid,malah sengaja buat tools ini untuk di jalankan diandroid:)
<br>
oh iya,btw tools ini kurang work kalo dijalanin ditermux jadi ada agak sedikit problem:)
<br>
<br>
next tutorial.
<br>
<br>
#TERMUX
<br>
$ git clone https://github.com/LOoLzeC/DarkSploit
<br>
$ cd DarkSploit
<br>
$ cd Install
<br>
$ sh installtermux.sh
<br>
$ pip2 install -r requirements.txt
<br>
$ cd ..
<br>
$ python2 DrXp.py
<br>
#Done.
<br>
<br>
#GNUROOT
<br>
$ git clone https://github.com/LOoLzeC/DarkSploit
<br>
$ cd DarkSploit
<br>
$ cd Install
<br>
$ sh installgnuroot.sh
<br>
$ pip2 install -r requirements.txt
<br>
$ cd ..
<br>
$ python2 DrXp.py
<br>
#Finish
<br>
<br>
U can update this program with command "darksploit update"
<br>
<br>
if you have a bug is running this program?report bug on my instagram.
<br>
contact instagram : @yungreyyxrist
